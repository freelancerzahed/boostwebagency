"use client"

import ContactForm from "@/components/ContactForm"

export default function ContactClient() {
  return <ContactForm />
}
