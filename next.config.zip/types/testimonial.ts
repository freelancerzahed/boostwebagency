export interface Testimonial {
  id: number | string
  name: string
  position: string
  image?: string
  content: string
  rating: number
}
