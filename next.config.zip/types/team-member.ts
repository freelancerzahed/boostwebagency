export interface TeamMember {
  id: string
  name: string
  role: string
  photo: string
}
