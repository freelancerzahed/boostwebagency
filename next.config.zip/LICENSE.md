# License Agreement

## Commercial License

This template is licensed for commercial use on ThemeForest/Envato Market.

### What you CAN do:
- Use the template to create websites for yourself or clients
- Modify and customize the template as needed
- Create multiple end products (websites) using this template

### What you CANNOT do:
- Resell, redistribute, or share the template source code
- Use the template to create competing products
- Share your license with others

### Support
For support and updates, please contact the author through ThemeForest.

### Credits
- Next.js - https://nextjs.org/
- React - https://react.dev/
- Tailwind CSS - https://tailwindcss.com/
- shadcn/ui - https://ui.shadcn.com/
- Lucide Icons - https://lucide.dev/

---

© 2025 Boost Web Agency. All rights reserved.
